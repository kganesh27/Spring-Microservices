package com.spring.feignclientservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeignClientServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
